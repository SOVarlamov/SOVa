const API = {
  async get(url){
    const r = await fetch(url, {headers: {"Content-Type":"application/json"}});
    return r.json();
  },
  async post(url, data){
    const r = await fetch(url, {method:"POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify(data||{})});
    return r.json();
  },
  async upload(url, formData){
    const r = await fetch(url, {method:"POST", body: formData});
    return r.json();
  }
};
function $(sel){ return document.querySelector(sel); }
function toast(msg){ alert(msg); }
function setOverlay(on){
  if(on){
    let o=document.getElementById('overlay'); if(!o){ o=document.createElement('div'); o.id='overlay'; o.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.2);z-index:9999'; document.body.appendChild(o); }
  }else{
    const o=document.getElementById('overlay'); if(o) o.remove();
  }
}
