export function statusBadge(state){
  const span = document.createElement('span'); span.className='badge';
  switch(state){
    case 'ok': span.classList.add('badge-ok'); span.textContent='🟢 Готово'; break;
    case 'warn': span.classList.add('badge-warn'); span.textContent='🟠 Неполная'; break;
    case 'absent': span.classList.add('badge-abs'); span.textContent='❌ Отсутствует'; break;
    default: span.classList.add('badge-new'); span.textContent='🔵 Новая';
  }
  return span;
}
