// Simple session
const Session = {
  get user(){ try{return JSON.parse(localStorage.getItem('user'))}catch{return null} },
  get token(){ return localStorage.getItem('token') },
};

function route(node){ const app=document.getElementById('app'); app.innerHTML=''; app.appendChild(node); }
function $(sel){ return document.querySelector(sel); }
function el(tag,props={},...children){ const n=document.createElement(tag); Object.assign(n,props); children.forEach(c=>n.append(c)); return n; }

window.addEventListener('DOMContentLoaded', ()=>{
  if(!Session.user){ location.href='../../auth/index.html'; return; }
  renderHome();
});

async function renderHome(){
  const wrap=el('div');
  const actions=el('div',{className:'card'});
  const start=el('button',{className:'btn btn-primary btn-block',textContent:'Начать новую анкету'});
  const logout=el('button',{className:'btn btn-secondary btn-block',textContent:'Выйти', style:'margin-top:8px'});
  actions.append(el('div',{className:'card-title',textContent:`Здравствуйте, ${Session.user.fio}`}), start, logout);

  const active=el('div',{className:'card'}); active.innerHTML=`<div class="card-title">Мои анкеты (черновики)</div><div id="list"></div>`;
  wrap.append(actions,active); route(wrap);

  start.onclick = renderStart;
  logout.onclick = ()=>{ localStorage.clear(); location.href='../../auth/index.html'; };
  reloadActive();
}

async function reloadActive(){
  const box=$('#list'); box.textContent='Загрузка...';
  const r=await API.get(`/visual_noise/v1/api/checks/active?user=${encodeURIComponent(Session.user.fio)}`);
  box.innerHTML='';
  (r.items||[]).forEach(m=>{
    const c=el('div',{className:'card'});
    c.innerHTML=`<div class="card-title">${m.hospital} / ${m.object}</div><div>ID: ${m.check_id}</div>`;
    const open=el('button',{className:'btn btn-primary',textContent:'Открыть зоны'});
    const delb=el('button',{className:'btn btn-danger',textContent:'Удалить', style:'margin-left:8px'});
    const close=el('button',{className:'btn btn-success',textContent:'Закрыть анкету', style:'margin-left:8px'});
    const prev=el('button',{className:'btn',textContent:'Предпросмотр', style:'margin-left:8px'});
    c.append(open,prev,delb,close); box.append(c);
    open.onclick=()=>renderZones(m);
    prev.onclick=()=>previewCheck(m);
    delb.onclick=async()=>{ if(!confirm('Удалить анкету?'))return; const rr=await API.post('/visual_noise/v1/api/checks/delete',{user:Session.user.fio,check_id:m.check_id}); if(rr.ok){alert('Удалено'); reloadActive();}}
    close.onclick=()=>closeCheckFlow(m);
  })
}

function previewCheck(meta){
  const w=el('div');
  w.append(el('div',{className:'card',innerHTML:`<div class="card-title">Предпросмотр анкеты</div><div>${meta.hospital} / ${meta.object} — ID: ${meta.check_id}</div>`}));
  const body=el('div',{className:'card'}); body.innerHTML='<div id="pv"></div>';
  const back=el('button',{className:'btn btn-secondary btn-block',textContent:'Назад'});
  w.append(body,back); route(w);

  API.get(`/visual_noise/v1/api/settings/zones?hospital=${encodeURIComponent(meta.hospital)}&object=${encodeURIComponent(meta.object)}`).then(r=>{
    const pv=$('#pv'); pv.innerHTML='';
    (r.items||[]).forEach(z=>pv.append(el('div',{className:'card',innerHTML:`<div><b>${z.zone}</b></div>`})));
  });
  back.onclick=renderHome;
}

function renderStart(){
  const w=el('div',{className:'card'}); w.innerHTML=`<div class="card-title">Новая анкета</div>`;
  const f1=el('div',{className:'field'}); f1.innerHTML=`<label class="label">Больница</label><select id="hosp" class="select"><option value="">—</option></select>`;
  const f2=el('div',{className:'field'}); f2.innerHTML=`<label class="label">Объект</label><select id="obj" class="select"><option value="">—</option></select>`;
  const next=el('button',{className:'btn btn-primary btn-block',textContent:'Продолжить'});
  const back=el('button',{className:'btn btn-secondary btn-block',textContent:'Назад', style:'margin-top:8px'});
  w.append(f1,f2,next,back); route(w);

  API.get('/visual_noise/v1/api/settings/hospitals').then(r=>{
    const s=$('#hosp'); (r.items||[]).forEach(h=>{const o=document.createElement('option');o.value=h;o.textContent=h;s.appendChild(o);})
  });
  document.getElementById('hosp').onchange=async e=>{
    const hosp=e.target.value;
    const r=await API.get(`/visual_noise/v1/api/settings/objects?hospital=${encodeURIComponent(hosp)}`);
    const s=document.getElementById('obj'); s.innerHTML='<option value="">—</option>';
    (r.items||[]).forEach(o=>{const x=document.createElement('option');x.value=o;x.textContent=o;s.appendChild(x);});
  };
  next.onclick=async ()=>{
    const hosp=document.getElementById('hosp').value.trim();
    const obj=document.getElementById('obj').value.trim();
    if(!hosp||!obj){alert('Выберите больницу и объект');return;}
    const r=await API.post('/visual_noise/v1/api/checks/start',{user:Session.user.fio, hospital:hosp, object:obj});
    if(r.ok){ alert('Анкета создана'); renderZones(r.meta); }
  };
  back.onclick=renderHome;
}

async function renderZones(meta){
  const w=el('div');
  const head=el('div',{className:'card'}); head.innerHTML=`<div class="card-title">${meta.hospital} / ${meta.object}</div><div>ID: ${meta.check_id}</div>`;
  const list=el('div',{className:'card'}); list.innerHTML=`<div class="card-title">Зоны</div><div id="zones"></div>`;
  const back=el('button',{className:'btn btn-secondary btn-block',textContent:'Назад'});
  w.append(head,list,back); route(w);

  const zonesBox=$('#zones');
  const r=await API.get(`/visual_noise/v1/api/settings/zones?hospital=${encodeURIComponent(meta.hospital)}&object=${encodeURIComponent(meta.object)}`);
  zonesBox.innerHTML='';
  (r.items||[]).forEach(item=>{
    const c=el('div',{className:'card'});
    c.append(el('div',{className:'card-title',textContent:item.zone}));
    const open=el('button',{className:'btn btn-primary',textContent:'Открыть'});
    c.append(open); zonesBox.append(c);
    open.onclick=()=>renderZone(meta, item.zone);
  });

  back.onclick=renderHome;
}

async function renderZone(meta, zone){
  const wrap=el('div');
  const head=el('div',{className:'card'});
  head.innerHTML=`<div class="card-title">${meta.hospital} / ${meta.object}</div><div>Зона: ${zone}</div>`;
  wrap.append(head);

  const nav=el('div',{className:'tabbar'});
  const tabs=[{k:'general', t:'📸 Фото общего плана'},{k:'new', t:'⚠️ Новые нарушения'},{k:'old', t:'♻️ Старые нарушения'}];
  tabs.forEach(tt=>{
    const b=el('button',{className:'tabbtn',textContent:tt.t});
    b.onclick=()=>showTab(tt.k);
    b.dataset.tab=tt.k;
    nav.append(b);
  });
  wrap.append(nav);

  const tabGeneral=el('div',{id:'tab-general', className:'tabcontent'});
  const tabNew=el('div',{id:'tab-new', className:'tabcontent', style:'display:none'});
  const tabOld=el('div',{id:'tab-old', className:'tabcontent', style:'display:none'});

  const genCard=el('div',{className:'card'});
  const genTitle=el('div',{className:'card-title',textContent:'Фото общего плана'});
  const genActions=el('div');
  const genView=el('button',{className:'btn',textContent:'Посмотреть/Скрыть'});
  const genAdd=el('button',{className:'btn btn-secondary',textContent:'Добавить фото', style:'margin-left:8px'});
  const genGallery=el('div',{className:'gallery', style:'display:none'});
  genActions.append(genView,genAdd);
  genCard.append(genTitle,genActions,genGallery);
  tabGeneral.append(genCard);

  const newCard=el('div',{className:'card'});
  newCard.innerHTML=`<div class="card-title">Новые нарушения</div>`;
  const addV=el('button',{className:'btn btn-primary',textContent:'Добавить нарушение'});
  const newBox=el('div'); newCard.append(addV,newBox); tabNew.append(newCard);

  const oldCard=el('div',{className:'card'});
  oldCard.innerHTML=`<div class="card-title">Старые нарушения</div>`;
  const oldBox=el('div'); oldCard.append(oldBox); tabOld.append(oldCard);

  const footer=el('div',{className:'card'});
  const save=el('button',{className:'btn btn-success btn-block',textContent:'💾 Сохранить изменения'});
  const absent=el('button',{className:'btn btn-danger btn-block',textContent:'🚫 Зона отсутствует', style:'margin-top:8px'});
  const restore=el('button',{className:'btn btn-secondary btn-block',textContent:'🔄 Вернуть в работу', style:'margin-top:8px; display:none'});
  const back=el('button',{className:'btn btn-secondary btn-block',textContent:'К списку зон', style:'margin-top:8px'});
  footer.append(save,absent,restore,back);

  wrap.append(tabGeneral,tabNew,tabOld,footer);
  route(wrap);

  const zresp = await API.get(`/visual_noise/v1/api/zones/open?user=${encodeURIComponent(Session.user.fio)}&check_id=${encodeURIComponent(meta.check_id)}&zone=${encodeURIComponent(zone)}`);
  if(!zresp.ok){ alert('Ошибка зоны'); return; }
  let zstate = zresp.zone || {};

  function renderGeneral(){
    genGallery.innerHTML='';
    const arr = zstate.general_photos||[];
    if(arr.length===0) genGallery.append(el('div',{className:'muted',textContent:'Фотографий нет'}));
    arr.forEach(p=>{
      const img=el('img',{className:'thumb'});
      const qp=encodeURIComponent(p);
      img.src=`/visual_noise/v1/api/media/preview?path=${qp}`;
      img.title='Нажмите чтобы удалить';
      img.onclick=async()=>{
        if(!confirm('Удалить фото общего плана?'))return;
        const fd=new FormData();
        fd.append('user',Session.user.fio); fd.append('check_id',meta.check_id); fd.append('zone',zone);
        fd.append('kind','gen'); fd.append('key',''); fd.append('path',p);
        setOverlay(true); await API.upload('/visual_noise/v1/api/media/delete', fd); setOverlay(false);
        zstate.general_photos = zstate.general_photos.filter(x=>x!==p);
        renderGeneral();
      };
      genGallery.append(img);
    });
  }
  function addGeneral(){
    const inp=document.createElement('input'); inp.type='file'; inp.accept='image/*'; inp.capture='environment'; inp.multiple=true;
    inp.onchange=async e=>{
      const files=Array.from(e.target.files||[]);
      for(const f of files){
        const fd=new FormData();
        fd.append('user',Session.user.fio); fd.append('check_id',meta.check_id); fd.append('zone',zone);
        fd.append('kind','gen'); fd.append('key',''); fd.append('file',f);
        setOverlay(true); await API.upload('/visual_noise/v1/api/media/upload', fd); setOverlay(false);
      }
      const z=await API.get(`/visual_noise/v1/api/zones/open?user=${encodeURIComponent(Session.user.fio)}&check_id=${encodeURIComponent(meta.check_id)}&zone=${encodeURIComponent(zone)}`);
      zstate=z.zone; renderGeneral();
    };
    inp.click();
  }
  genView.onclick=()=>{ genGallery.style.display=(genGallery.style.display==='none'?'flex':'none'); if(genGallery.style.display!=='none') renderGeneral(); };
  genAdd.onclick=addGeneral;

  addV.onclick=()=>{
    const card=el('div',{className:'card'});
    const fv=el('div',{className:'field'}); fv.innerHTML=`<label class="label">Нарушение</label><input class="input" placeholder="Тип нарушения">`;
    const fc=el('div',{className:'field'}); fc.innerHTML=`<label class="label">Комментарий</label><textarea class="textarea"></textarea>`;
    const fp=el('input'); fp.type='file'; fp.accept='image/*'; fp.capture='environment'; fp.multiple=true; fp.disabled=true;
    const saveBtn=el('button',{className:'btn btn-primary',textContent:'Сохранить нарушение'});
    card.append(fv,fc,saveBtn,fp); newBox.append(card);

    saveBtn.onclick=async ()=>{
      const title=fv.querySelector('input').value.trim();
      const comment=fc.querySelector('textarea').value.trim();
      if(!title){alert('Укажите текст нарушения'); return;}
      const r=await API.post('/visual_noise/v1/api/zones/new-violation',{user:Session.user.fio, check_id:meta.check_id, zone, title, comment});
      if(!r.ok){alert('Ошибка');return;}
      const vkey=r.key; fp.disabled=false; alert('Нарушение сохранено. Добавьте фото.');
      fp.onchange=async e=>{
        const files=Array.from(e.target.files||[]);
        for(const f of files){
          const fd=new FormData();
          fd.append('user',Session.user.fio); fd.append('check_id',meta.check_id); fd.append('zone',zone);
          fd.append('kind','vio'); fd.append('key', vkey); fd.append('file',f);
          setOverlay(true); await API.upload('/visual_noise/v1/api/media/upload', fd); setOverlay(false);
        }
        alert('Фото нарушения сохранены');
      };
    };
  };

  (async ()=>{
    const r=await API.get(`/visual_noise/v1/api/violations/old?hospital=${encodeURIComponent(meta.hospital)}&object=${encodeURIComponent(meta.object)}&zone=${encodeURIComponent(zone)}`);
    oldBox.innerHTML='';
    (r.items||[]).forEach(v=>{
      const c=el('div',{className:'card'});
      c.innerHTML=`<div class="card-title">${v.violation}</div>`;
      const sel=el('select',{className:'select'}); sel.innerHTML='<option value="">— статус —</option><option>Актуально</option><option>Устранено</option>';
      const fix=el('input'); fix.type='file'; fix.accept='image/*'; fix.capture='environment'; fix.multiple=true; fix.style.display='none';
      sel.onchange=async ()=>{
        fix.style.display=(sel.value==='Устранено')?'block':'none';
        await API.post('/visual_noise/v1/api/zones/old-status',{user:Session.user.fio, check_id:meta.check_id, zone, violation:v.violation, status:sel.value});
        alert('Статус сохранён');
      };
      fix.onchange=async e=>{
        const files=Array.from(e.target.files||[]);
        for(const f of files){
          const fd=new FormData();
          fd.append('user',Session.user.fio); fd.append('check_id',meta.check_id); fd.append('zone',zone);
          fd.append('kind','fix'); fd.append('key', v.violation); fd.append('file',f);
          setOverlay(true); await API.upload('/visual_noise/v1/api/media/upload', fd); setOverlay(false);
        }
        alert('Фото устранения сохранены');
      };
      c.append(sel,fix); oldBox.append(c);
    });
  })();

  function refreshAbsentUI(){
    const isAbs = !!zstate.absent;
    absent.style.display = isAbs ? 'none' : 'block';
    restore.style.display = isAbs ? 'block' : 'none';
  }
  refreshAbsentUI();

  absent.onclick=async ()=>{
    if(!confirm('Отметить зону как отсутствующую? Все данные по зоне будут очищены.'))return;
    const r=await API.post('/visual_noise/v1/api/zones/absent',{user:Session.user.fio, check_id:meta.check_id, zone, absent:true});
    if(r.ok){ zstate.absent=true; zstate.general_photos=[]; zstate.new_violations=[]; zstate.old_updates=[]; refreshAbsentUI(); alert('Зона отмечена как отсутствующая'); }
  };
  restore.onclick=async ()=>{
    const r=await API.post('/visual_noise/v1/api/zones/absent',{user:Session.user.fio, check_id:meta.check_id, zone, absent:false});
    if(r.ok){ zstate.absent=false; refreshAbsentUI(); alert('Зона возвращена в работу'); }
  };

  let firstSaveHintShown=false;
  save.onclick=async ()=>{
    if(!firstSaveHintShown){
      firstSaveHintShown=true;
      if(!(zstate.general_photos||[]).length && !zstate.absent){
        if(!confirm('Рекомендуется добавить фото общего плана. Продолжить без фото?')) return;
        zstate.photo_warning = true;
      }
    }
    const ok = await API.post('/visual_noise/v1/api/zones/save',{user:Session.user.fio, check_id:meta.check_id, zone, zone_state: zstate});
    if(ok && ok.ok){ alert('Сохранено'); } else { alert('Ошибка сохранения'); }
  };

  back.onclick=()=>renderZones(meta);

  function showTab(k){
    document.querySelectorAll('.tabbtn').forEach(b=>b.classList.toggle('active', b.dataset.tab===k));
    document.getElementById('tab-general').style.display = (k==='general'?'block':'none');
    document.getElementById('tab-new').style.display = (k==='new'?'block':'none');
    document.getElementById('tab-old').style.display = (k==='old'?'block':'none');
    if(k==='general' && genGallery.style.display!=='none') renderGeneral();
  }
  showTab('general');
}

async function closeCheckFlow(meta){
  if(!confirm('Закрыть анкету и выгрузить данные?')) return;
  setOverlay(true);
  const rr=await API.post('/visual_noise/v1/api/checks/close',{user:Session.user.fio,check_id:meta.check_id});
  setOverlay(false);
  if(rr.ok){ alert(`Анкета закрыта: записей=${rr.added}, обновлено=${rr.updated}, фото=${rr.photos}`); renderHome(); }
  else if(rr.errors){ alert('Исправьте ошибки:\n\n• ' + rr.errors.join('\n• ')); }
  else alert(rr.error||'Ошибка закрытия');
}
