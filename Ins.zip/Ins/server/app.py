import os
import sys
from importlib import import_module
from flask import Flask, send_from_directory
from dotenv import load_dotenv

# ---------- sys.path: делаем видимым пакет "server" при любом способе запуска
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # .../Ins
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

# ---------- env & logging
load_dotenv()

# Безопасные дефолты
HOST = os.getenv("HOST", "127.0.0.1")
PORT = int(os.getenv("PORT", "8000"))
DEBUG = os.getenv("DEBUG", "false").strip().lower() in ("1", "true", "yes", "on")

# Пути до фронта
CLIENT_DIR = os.path.join(BASE_DIR, "client")
ASSETS_DIR = os.path.join(CLIENT_DIR, "assets")
VN_DIR = os.path.join(CLIENT_DIR, "projects", "visual_noise")
VN_ASSETS_DIR = os.path.join(VN_DIR, "assets")

# Логирование и очереди
from server.core.logsetup import setup_logging
from server.core.drive_queue import drive_queue

setup_logging()

# ---------- Flask app
# Не даём Flask'у свой static_folder, чтобы контролировать маршруты вручную
app = Flask(__name__, static_folder=None, template_folder=None)


# ---------- Кэш-заголовки на статику
def _nocache(resp):
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"] = "no-cache"
    resp.headers["Expires"] = "0"
    return resp


# ---------- Маршруты фронтенда

@app.get("/")
def home():
    # Стартовая: страница авторизации
    resp = send_from_directory(os.path.join(CLIENT_DIR, "auth"), "index.html")
    return _nocache(resp)


@app.get("/auth")
def auth_page():
    # То же самое, но по явному пути /auth
    resp = send_from_directory(os.path.join(CLIENT_DIR, "auth"), "index.html")
    return _nocache(resp)


@app.get("/admin")
def admin_page():
    resp = send_from_directory(os.path.join(CLIENT_DIR, "admin"), "index.html")
    return _nocache(resp)


@app.get("/projects/visual_noise")
def visual_noise_page():
    resp = send_from_directory(VN_DIR, "index.html")
    return _nocache(resp)


# ---------- Статика (общая)
@app.get("/assets/<path:path>")
def assets(path):
    return send_from_directory(ASSETS_DIR, path)


# ---------- Статика проекта visual_noise
@app.get("/projects/visual_noise/assets/<path:path>")
def vn_assets(path):
    return send_from_directory(VN_ASSETS_DIR, path)


# ---------- favicon (пока нет — отдаём пустой ответ)
@app.get("/favicon.ico")
def favicon():
    # Можно вернуть 204 без тела, чтобы не было красной ошибки в консоли
    return ("", 204)


# ---------- API и блюпринты

# Авторизация
from server.auth.routes import bp_auth
app.register_blueprint(bp_auth)

# Админ АПИ
from server.admin.api import bp as admin_bp
app.register_blueprint(admin_bp)


def register_projects():
    modules = [
        "server.projects.visual_noise.api",
    ]
    for module_path in modules:
        mod = import_module(module_path)
        bp = getattr(mod, "bp", None)
        if bp:
            app.register_blueprint(bp)


register_projects()

# ---------- Фоновая очередь (как было в проекте)
drive_queue.start()


# ---------- Run
if __name__ == "__main__":
    app.run(host=HOST, port=PORT, debug=DEBUG)
