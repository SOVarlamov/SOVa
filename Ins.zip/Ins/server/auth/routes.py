import os
import json
from datetime import datetime

from flask import Blueprint, request, jsonify
import gspread

from server.core.auth_tokens import sign

bp_auth = Blueprint("auth", __name__)

# --- Конфиг авторизации через Google Sheets ---

AUTH_SPREADSHEET_ID = os.getenv("AUTH_SPREADSHEET_ID")
AUTH_CODES_SHEET = os.getenv("AUTH_CODES_SHEET", "Коды")
AUTH_LOG_SHEET = os.getenv("AUTH_LOG_SHEET", "Лог")


def _get_gspread_client():
    sa_json = os.getenv("GOOGLE_SERVICE_ACCOUNT_JSON")
    if not sa_json:
        raise RuntimeError("GOOGLE_SERVICE_ACCOUNT_JSON не задан в .env")
    try:
        info = json.loads(sa_json)
    except json.JSONDecodeError as e:
        raise RuntimeError("GOOGLE_SERVICE_ACCOUNT_JSON содержит некорректный JSON") from e
    return gspread.service_account_from_dict(info)


def _find_user_exact(fio_typed: str, code: str):
    """
    Строгая авторизация:
    ✓ must match both: FIO AND CODE
    """
    client = _get_gspread_client()
    sh = client.open_by_key(AUTH_SPREADSHEET_ID)
    ws = sh.worksheet(AUTH_CODES_SHEET)

    rows = ws.get_all_values()
    if not rows:
        return None

    headers = rows[0]

    try:
        code_idx = headers.index("Код")
    except ValueError:
        code_idx = 0

    try:
        fio_idx = headers.index("ФИО")
    except ValueError:
        # Если нет колонки ФИО — строгая проверка невозможна
        return None

    role_idx = headers.index("Роль") if "Роль" in headers else None

    fio_typed_norm = fio_typed.strip().lower()

    for row in rows[1:]:
        if len(row) <= max(code_idx, fio_idx):
            continue

        row_code = (row[code_idx] or "").strip()
        row_fio = (row[fio_idx] or "").strip()

        # Строгое совпадение ФИО + код
        if row_code == code and row_fio.lower().strip() == fio_typed_norm:

            role = "user"
            if role_idx is not None and row[role_idx].strip():
                role = row[role_idx].strip()

            return {"fio": row_fio, "role": role}

    return None


def _log_auth(fio: str, code: str, success: bool, reason: str = ""):
    if not AUTH_SPREADSHEET_ID:
        return
    try:
        client = _get_gspread_client()
        sh = client.open_by_key(AUTH_SPREADSHEET_ID)
        try:
            ws = sh.worksheet(AUTH_LOG_SHEET)
        except gspread.WorksheetNotFound:
            ws = sh.add_worksheet(title=AUTH_LOG_SHEET, rows=1000, cols=10)
            ws.append_row(
                ["Время", "ФИО", "Код", "Статус", "Комментарий"],
                value_input_option="USER_ENTERED",
            )
        ws.append_row(
            [
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                fio,
                code,
                "OK" if success else "FAIL",
                reason,
            ],
            value_input_option="USER_ENTERED",
        )
    except Exception:
        pass


@bp_auth.post("/auth/login")
def login():
    data = request.get_json(force=True, silent=True) or {}
    fio_typed = (data.get("fio") or "").strip()
    code = (data.get("code") or "").strip()

    if not fio_typed or not code:
        return jsonify({"ok": False, "error": "REQUIRED"}), 400

    if not AUTH_SPREADSHEET_ID:
        return jsonify({"ok": False, "error": "CONFIG"}), 500

    try:
        user_info = _find_user_exact(fio_typed, code)
    except Exception as e:
        _log_auth(fio_typed, code, False, f"ERROR: {e}")
        return jsonify({"ok": False, "error": "GSHEETS"}), 500

    if not user_info:
        _log_auth(fio_typed, code, False, "FIO OR CODE MISMATCH")
        return jsonify({"ok": False, "error": "INVALID"}), 403

    _log_auth(user_info["fio"], code, True, "OK")

    token = sign(user_info)
    return jsonify({"ok": True, "token": token, "user": user_info})
