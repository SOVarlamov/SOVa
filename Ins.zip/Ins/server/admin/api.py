import os
from flask import Blueprint, request, jsonify

bp = Blueprint("admin", __name__, url_prefix="/admin/v1")

LOG_DIR = os.getenv("LOG_DIR","server/logs")

@bp.get("/api/logs")
def api_logs():
    typ = (request.args.get("type") or "actions").lower()
    lines = int(request.args.get("lines","200"))
    name = {"actions":"actions.log","media":"media.log","errors":"errors.log","api":"api.log","access":"access.log"}.get(typ,"actions.log")
    path = os.path.join(LOG_DIR, name)
    data=[]
    if os.path.exists(path):
        with open(path,"r",encoding="utf-8",errors="ignore") as f:
            data = f.readlines()[-lines:]
    return jsonify({"ok": True, "type": typ, "lines": data})

@bp.get("/api/stats")
def api_stats():
    path = os.path.join(LOG_DIR, "actions.log")
    closed=0; archived=0
    if os.path.exists(path):
        with open(path,"r",encoding="utf-8",errors="ignore") as f:
            for line in f:
                if "check_finalize" in line: closed += 1
                if "snapshot_archived" in line: archived += 1
    return jsonify({"ok": True, "closed_checks": closed, "archived_snapshots": archived})
