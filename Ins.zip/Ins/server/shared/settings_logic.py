import os
from server.core.google_api import open_sheet_by_id

SETTINGS_SHEET = os.getenv("SHEET_SETTINGS","Настройки")
USERS_SHEET = os.getenv("SHEET_USERS","Пользователи")

def list_hospitals(sheet_id: str):
    ws = open_sheet_by_id(sheet_id).worksheet(SETTINGS_SHEET)
    rows = ws.get_all_values()
    if not rows: return []
    return sorted(set([r[0].strip() for r in rows[1:] if len(r)>0 and r[0].strip()]))

def list_objects(sheet_id: str, hospital: str):
    ws = open_sheet_by_id(sheet_id).worksheet(SETTINGS_SHEET)
    rows = ws.get_all_values()
    out=set()
    for r in rows[1:]:
        if len(r)>3 and r[0].strip()==hospital.strip():
            out.add(r[3].strip())
    return sorted(out)

def list_zones(sheet_id: str, hospital: str, object_name: str):
    ws = open_sheet_by_id(sheet_id).worksheet(SETTINGS_SHEET)
    rows = ws.get_all_values()
    out=[]
    for r in rows[1:]:
        if len(r)>7 and r[0].strip()==hospital.strip() and r[3].strip()==object_name.strip():
            zone = r[7].strip()
            if zone: out.append({"zone": zone})
    seen=set(); uniq=[]
    for z in out:
        if z["zone"] not in seen:
            uniq.append(z); seen.add(z["zone"])
    return uniq

def photo_rules(sheet_id: str, hospital: str, zone: str, violation: str|None):
    ws = open_sheet_by_id(sheet_id).worksheet(SETTINGS_SHEET)
    rows = ws.get_all_values()

    min_zone = 0; max_zone = None
    min_v = 0; max_v = None
    comment_required = False

    for r in rows[1:]:
        if len(r) < 19: continue
        hosp = r[0].strip()
        zn   = r[7].strip()  # H - Зона
        crit = r[9].strip()  # J - Критерий нарушения
        k_v  = (r[10] or "").strip()  # K - Кол-во фото для критерия
        l_c  = (r[11] or "").strip()  # L - Флаг необходимости комментария
        r_zone = (r[17] or "").strip() # R - Кол-во фото для зоны
        if hosp != hospital: continue
        if zone and zn and zn != zone: continue

        if r_zone:
            if "-" in r_zone:
                a,b = r_zone.split("-",1)
                try:
                    min_zone = max(min_zone, int(a.strip()))
                    max_zone = int(b.strip())
                except: pass
            else:
                try:
                    exact = int(r_zone)
                    min_zone = max(min_zone, exact)
                    max_zone = exact
                except: pass

        if violation and crit and crit.lower()==violation.lower():
            if k_v:
                if "-" in k_v:
                    a,b = k_v.split("-",1)
                    try:
                        min_v = max(min_v, int(a.strip()))
                        max_v = int(b.strip())
                    except: pass
                else:
                    try:
                        exact = int(k_v)
                        min_v = max(min_v, exact)
                        max_v = exact
                    except: pass
            if l_c:
                comment_required = (l_c.strip() not in ("0","нет","false","False"))

    return {
        "min_photos_zone": min_zone,
        "max_photos_zone": max_zone,
        "min_photos_violation": min_v,
        "max_photos_violation": max_v,
        "comment_required": comment_required
    }
