import os, logging
from PIL import Image
from server.core.utils import ensure_dir

log = logging.getLogger("media")

def local_save_image(file_storage, target_dir: str, base_name: str):
    ensure_dir(target_dir)
    img = Image.open(file_storage.stream)
    img = img.convert("RGB")
    path = os.path.join(target_dir, f"{base_name}.jpg")
    img.save(path, "JPEG", quality=80, optimize=True)
    log.info(f"local_image_saved path={path}")
    return path
