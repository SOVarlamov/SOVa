import os
from PIL import Image

def get_or_create_thumbnail(path: str, size=(200,200)):
    if not os.path.isfile(path): return None
    base, _ = os.path.splitext(path)
    thumb_path = base + "_thumb.webp"
    try:
        if os.path.exists(thumb_path) and os.path.getmtime(thumb_path) >= os.path.getmtime(path):
            return thumb_path
        im = Image.open(path)
        im.thumbnail(size)
        im.save(thumb_path, "WEBP", quality=70)
        return thumb_path
    except Exception:
        return None
