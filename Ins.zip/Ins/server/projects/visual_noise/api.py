import os, urllib.parse
from flask import Blueprint, request, jsonify, send_file
from server.shared.settings_logic import list_hospitals, list_objects, list_zones, photo_rules
from server.projects.visual_noise.logic.checks import (
    start_check, list_active_checks, delete_check,
    open_zone, save_zone_state, create_violation, set_old_status, attach_photo,
    finalize_check, set_zone_absent, remove_photo
)
from server.projects.visual_noise.logic.violations import (
    list_old_violations, append_violation, update_status_by_match
)

bp = Blueprint("visual_noise", __name__, url_prefix="/visual_noise/v1")

def _sheet_id():
    sid = os.getenv("GSHEET_ID_VISUAL_NOISE","").strip()
    if not sid: raise RuntimeError("GSHEET_ID_VISUAL_NOISE not set")
    return sid

@bp.get("/api/settings/hospitals")
def api_hosp(): return jsonify({"ok": True, "items": list_hospitals(_sheet_id())})

@bp.get("/api/settings/objects")
def api_obj():
    hosp = (request.args.get("hospital") or "").strip()
    return jsonify({"ok": True, "items": list_objects(_sheet_id(), hosp)})

@bp.get("/api/settings/zones")
def api_z():
    hosp = (request.args.get("hospital") or "").strip()
    obj = (request.args.get("object") or "").strip()
    return jsonify({"ok": True, "items": list_zones(_sheet_id(), hosp, obj)})

@bp.get("/api/settings/photo-rules")
def api_rules():
    hosp = request.args.get("hospital"); zone = request.args.get("zone"); viol = request.args.get("violation")
    return jsonify({"ok": True, "items": photo_rules(_sheet_id(), hosp, zone, viol)})

@bp.post("/api/checks/start")
def api_check_start():
    d = request.get_json(force=True, silent=True) or {}
    meta = start_check(d.get("user",""), d.get("hospital",""), d.get("object",""), "VISUAL_NOISE")
    return jsonify({"ok": True, "meta": meta})

@bp.get("/api/checks/active")
def api_check_active():
    u = request.args.get("user","")
    return jsonify({"ok": True, "items": list_active_checks(u)})

@bp.post("/api/checks/delete")
def api_check_del():
    d = request.get_json(force=True, silent=True) or {}
    ok = delete_check(d.get("user",""), d.get("check_id",""))
    return jsonify({"ok": bool(ok)}), (200 if ok else 404)

@bp.post("/api/checks/close")
def api_check_close():
    d = request.get_json(force=True, silent=True) or {}
    user = d.get("user",""); check_id=d.get("check_id","")
    res = finalize_check(
        project_sheet_id=_sheet_id(), project_key="VISUAL_NOISE", user_fio=user, check_id=check_id,
        add_violation_fn=lambda **kw: append_violation(_sheet_id(), **kw),
        update_old_fn=lambda **kw: update_status_by_match(_sheet_id(), **kw),
        force=False
    )
    code = 200 if res.get("ok") else 400
    return jsonify(res), code

@bp.get("/api/zones/open")
def api_zone_open():
    u = request.args.get("user",""); chk = request.args.get("check_id",""); z = request.args.get("zone","")
    return jsonify(open_zone(u,chk,z))

@bp.post("/api/zones/save")
def api_zone_save():
    d = request.get_json(force=True, silent=True) or {}
    ok = save_zone_state(d.get("user",""), d.get("check_id",""), d.get("zone",""), d.get("zone_state") or {})
    return jsonify({"ok": bool(ok)})

@bp.post("/api/zones/absent")
def api_zone_absent():
    d = request.get_json(force=True, silent=True) or {}
    ok = set_zone_absent(d.get("user",""), d.get("check_id",""), d.get("zone",""), bool(d.get("absent",True)))
    return jsonify({"ok": bool(ok)})

@bp.post("/api/zones/new-violation")
def api_zone_new_violation():
    d = request.get_json(force=True, silent=True) or {}
    key = create_violation(d.get("user",""), d.get("check_id",""), d.get("zone",""), d.get("title",""), d.get("comment",""))
    if not key: return jsonify({"ok": False}), 400
    return jsonify({"ok": True, "key": key})

@bp.post("/api/zones/old-status")
def api_zone_old_status():
    d = request.get_json(force=True, silent=True) or {}
    ok = set_old_status(d.get("user",""), d.get("check_id",""), d.get("zone",""), d.get("violation",""), d.get("status",""))
    return jsonify({"ok": bool(ok)}), (200 if ok else 400)

@bp.post("/api/media/upload")
def api_media_upload():
    user = request.form.get("user",""); check_id = request.form.get("check_id","")
    zone = request.form.get("zone",""); kind = request.form.get("kind","gen"); key = request.form.get("key","")
    file = request.files.get("file")
    if not file: return jsonify({"ok": False, "error": "NO_FILE"}), 400
    ok = attach_photo(user, check_id, zone, kind, key, file)
    return jsonify({"ok": bool(ok)}), (200 if ok else 400)

@bp.post("/api/media/delete")
def api_media_delete():
    user = request.form.get("user",""); check_id = request.form.get("check_id","")
    zone = request.form.get("zone",""); kind = request.form.get("kind","gen"); key = request.form.get("key","")
    path = request.form.get("path","")
    ok = remove_photo(user, check_id, zone, kind, key, path)
    return jsonify({"ok": bool(ok)}), (200 if ok else 400)

@bp.get("/api/media/preview")
def api_media_preview():
    path = request.args.get("path","")
    path = urllib.parse.unquote(path)
    from server.shared.thumbnails import get_or_create_thumbnail
    thumb = get_or_create_thumbnail(path)
    if not thumb: return ("",404)
    return send_file(thumb, mimetype="image/webp")

@bp.get("/api/violations/old")
def api_old():
    hosp = request.args.get("hospital",""); obj = request.args.get("object",""); zone = request.args.get("zone","")
    return jsonify({"ok": True, "items": list_old_violations(_sheet_id(), hosp, obj, zone)})
