import os
from server.core.google_api import open_sheet_by_id
from server.core.sheet_adapter import get_fields_map, get_all_as_dicts, append_row_by_map, write_row_values
from server.core.utils import split_links, now_str

DB_SHEET = os.getenv("SHEET_DB","БД")

def list_old_violations(project_sheet_id: str, hospital: str, object_name: str, zone: str):
    ws = open_sheet_by_id(project_sheet_id).worksheet(DB_SHEET)
    fmap = get_fields_map("db")
    rows = get_all_as_dicts(ws, fmap)
    out=[]
    for r in rows:
        if (r.get("hospital") or "").strip()!=hospital.strip(): continue
        if (r.get("object") or "").strip()!=object_name.strip(): continue
        if (r.get("zone") or "").strip()!=zone.strip(): continue
        if (r.get("violation") or "").strip().lower()=="нет": continue
        out.append({
            "violation": r.get("violation"),
            "status": r.get("status"),
            "photo_violation": split_links(r.get("photo_violation") or ""),
            "comment": r.get("comment"),
            "check_id": r.get("check_id"),
            "inspector": r.get("inspector"),
            "updated_at": r.get("updated_at")
        })
    return out

def append_violation(project_sheet_id: str, inspector: str, check_id: str, hospital: str, object_name: str, zone: str, violation: str, photo_violation_links: list, comment: str = None):
    ws = open_sheet_by_id(project_sheet_id).worksheet(DB_SHEET)
    fmap = get_fields_map("db")
    append_row_by_map(ws, {
        "hospital": hospital, "object": object_name, "zone": zone,
        "violation": violation,
        "photo_violation": " ".join(photo_violation_links or []),
        "comment": comment or "",
        "status": "Новое",
        "updated_at": now_str(),
        "inspector": inspector, "check_id": check_id
    }, fmap)
    return True

def update_status_by_match(project_sheet_id: str, hospital: str, object_name: str, zone: str, violation: str, new_status: str, photo_fix_links: list = None):
    ws = open_sheet_by_id(project_sheet_id).worksheet(DB_SHEET)
    fmap = get_fields_map("db")
    rows = ws.get_all_values()
    if not rows: return False
    headers = rows[0]

    idx = {}
    low = [h.strip().lower() for h in headers]
    import re
    for k,v in fmap.items():
        found = None
        for patt in v:
            for i, h in enumerate(low):
                if re.search(patt, h, re.IGNORECASE): found=i; break
            if found is not None: break
        idx[k]=found

    def cell(r, k):
        i = idx.get(k)
        return (r[i] if (i is not None and i < len(r)) else "")

    target_row = None
    for i,row in enumerate(rows[1:], start=2):
        if cell(row,"hospital").strip()==hospital.strip() and            cell(row,"object").strip()==object_name.strip() and            cell(row,"zone").strip()==zone.strip() and            cell(row,"violation").strip()==violation.strip():
            target_row = i; break

    if target_row:
        to_write={"status": new_status, "updated_at": now_str()}
        if photo_fix_links: to_write["photo_fix"]=" ".join(photo_fix_links)
        write_row_values(ws, target_row, to_write, fmap)
        return True

    append_row_by_map(ws, {
        "hospital": hospital, "object": object_name, "zone": zone,
        "violation": violation, "photo_violation": "",
        "comment": "", "status": new_status, "updated_at": now_str(),
        "inspector": "", "check_id": ""
    }, fmap)
    return True
