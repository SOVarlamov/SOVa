import os, json, uuid, logging
from datetime import datetime
from server.core.utils import ensure_dir, cleanup_snapshots, gen_id, log_actions, now_str
from server.core.google_api import drive_upload
from server.shared.media import local_save_image
from server.shared.thumbnails import get_or_create_thumbnail
from server.shared.settings_logic import photo_rules

SNAP_DIR = os.getenv("SNAPSHOTS_DIR", "server/snapshots")
TTL_HOURS = int(os.getenv("SNAPSHOTS_TTL_HOURS", "24"))

log = logging.getLogger("api")

# -------------------------------
# Вспомогательные функции
# -------------------------------

def _slug(s: str):
    import re
    s = (s or "").strip().lower()
    return re.sub(r"[^a-z0-9а-яё_]+", "-", s)

def _user_root(user_fio): 
    return ensure_dir(os.path.join(SNAP_DIR, _slug(user_fio)))

def _check_root(user_fio, check_id): 
    return ensure_dir(os.path.join(_user_root(user_fio), check_id))

def _meta_path(user_fio, check_id): 
    return os.path.join(_check_root(user_fio, check_id), "meta.json")

def _load_meta(user_fio, check_id):
    p = _meta_path(user_fio, check_id)
    if not os.path.exists(p): 
        return None
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)

def _save_meta(user_fio, check_id, meta: dict):
    p = _meta_path(user_fio, check_id)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)

# -------------------------------
# Работа с анкетой
# -------------------------------

def start_check(user_fio: str, hospital: str, object_name: str, project_key: str):
    cleanup_snapshots(SNAP_DIR, TTL_HOURS)
    check_id = gen_id("chk-")
    meta = {
        "check_id": check_id,
        "user": user_fio,
        "hospital": hospital,
        "object": object_name,
        "project_key": project_key,
        "status": "draft",
        "zones": {},
        "created_at": datetime.now().isoformat()
    }
    _save_meta(user_fio, check_id, meta)
    log_actions.info(f'check_start user="{user_fio}" id="{check_id}" hospital="{hospital}" object="{object_name}"')
    return meta

def list_active_checks(user_fio: str):
    cleanup_snapshots(SNAP_DIR, TTL_HOURS)
    udir = _user_root(user_fio)
    if not os.path.isdir(udir): 
        return []
    out = []
    for ch in os.listdir(udir):
        root = os.path.join(udir, ch)
        if not os.path.isdir(root): 
            continue
        m = os.path.join(root, "meta.json")
        if os.path.exists(m):
            with open(m, "r", encoding="utf-8") as f:
                meta = json.load(f)
                if (meta.get("status") or "draft") != "closed":
                    out.append(meta)
    out.sort(key=lambda m: m.get("created_at", ""), reverse=True)
    return out

def delete_check(user_fio: str, check_id: str):
    root = _check_root(user_fio, check_id)
    if not os.path.isdir(root): 
        return False
    for base, dirs, files in os.walk(root, topdown=False):
        for f in files:
            try: os.remove(os.path.join(base, f))
            except: pass
        for d in dirs:
            try: os.rmdir(os.path.join(base, d))
            except: pass
    try:
        os.rmdir(root)
        log_actions.info(f'check_delete user="{user_fio}" id="{check_id}"')
        return True
    except:
        return False

# -------------------------------
# Работа с зонами
# -------------------------------

def _ensure_zone(meta: dict, zone_name: str):
    z = meta["zones"].get(zone_name)
    if not z:
        z = {
            "absent": False,
            "photo_warning": False,
            "general_photos": [],
            "new_violations": [],
            "old_updates": []
        }
        meta["zones"][zone_name] = z
    return z

def open_zone(user_fio: str, check_id: str, zone: str):
    meta = _load_meta(user_fio, check_id)
    if not meta: 
        return {"ok": False, "error": "CHECK_NOT_FOUND"}
    z = _ensure_zone(meta, zone)
    os.makedirs(os.path.join(_check_root(user_fio, check_id), "zones", _slug(zone), "photos"), exist_ok=True)
    return {"ok": True, "zone": z}

def save_zone_state(user_fio: str, check_id: str, zone: str, zone_state: dict):
    meta = _load_meta(user_fio, check_id)
    if not meta: 
        return False
    zone_state.setdefault("absent", False)
    zone_state.setdefault("photo_warning", False)
    zone_state.setdefault("general_photos", [])
    zone_state.setdefault("new_violations", [])
    zone_state.setdefault("old_updates", [])
    meta["zones"][zone] = zone_state
    _save_meta(user_fio, check_id, meta)
    log_actions.info(f'zone_save user="{user_fio}" check="{check_id}" zone="{zone}"')
    return True

def set_zone_absent(user_fio: str, check_id: str, zone: str, absent: bool):
    meta = _load_meta(user_fio, check_id)
    if not meta: 
        return False
    z = _ensure_zone(meta, zone)
    z["absent"] = bool(absent)
    if z["absent"]:
        z["general_photos"] = []
        z["new_violations"] = []
        z["old_updates"] = []
    _save_meta(user_fio, check_id, meta)
    log_actions.info(f'zone_absent user="{user_fio}" check="{check_id}" zone="{zone}" absent={z["absent"]}')
    return True

# -------------------------------
# Нарушения и фото
# -------------------------------

def create_violation(user_fio: str, check_id: str, zone: str, title: str, comment: str = ""):
    meta = _load_meta(user_fio, check_id)
    if not meta: 
        return None
    z = _ensure_zone(meta, zone)
    key = uuid.uuid4().hex[:12]
    z["new_violations"].append({"key": key, "title": title or "", "comment": comment or "", "photos": []})
    _save_meta(user_fio, check_id, meta)
    return key

def set_old_status(user_fio: str, check_id: str, zone: str, violation_title: str, status: str):
    meta = _load_meta(user_fio, check_id)
    if not meta: 
        return False
    z = _ensure_zone(meta, zone)
    for it in z["old_updates"]:
        if (it.get("violation") or "") == (violation_title or ""):
            it["status"] = status
            _save_meta(user_fio, check_id, meta)
            return True
    z["old_updates"].append({"violation": violation_title or "", "status": status or "", "fix_photos": []})
    _save_meta(user_fio, check_id, meta)
    return True

def attach_photo(user_fio: str, check_id: str, zone: str, kind: str, key: str, file_storage):
    meta = _load_meta(user_fio, check_id)
    if not meta: 
        return False
    z = _ensure_zone(meta, zone)
    tdir = os.path.join(_check_root(user_fio, check_id), "zones", _slug(zone), "photos")
    path = local_save_image(file_storage, tdir, f"{kind}_{uuid.uuid4().hex[:8]}")
    if kind == "gen":
        z["general_photos"].append(path)
    elif kind == "vio":
        for v in z["new_violations"]:
            if v.get("key") == key:
                v["photos"].append(path)
                break
    elif kind == "fix":
        for it in z["old_updates"]:
            if (it.get("violation") or "") == (key or ""):
                it.setdefault("fix_photos", []).append(path)
                break
    _save_meta(user_fio, check_id, meta)
    return True

def remove_photo(user_fio: str, check_id: str, zone: str, kind: str, key: str, path: str):
    meta = _load_meta(user_fio, check_id)
    if not meta: 
        return False
    z = _ensure_zone(meta, zone)

    def _rmfile(p):
        try:
            if os.path.isfile(p): os.remove(p)
            t = os.path.splitext(p)[0] + "_thumb.webp"
            if os.path.isfile(t): os.remove(t)
        except:
            pass

    if kind == "gen":
        arr = z.get("general_photos", [])
        if path in arr:
            arr.remove(path)
            _rmfile(path)
    elif kind == "vio":
        for v in z.get("new_violations", []):
            if v.get("key") == key and path in v.get("photos", []):
                v["photos"].remove(path)
                _rmfile(path)
    elif kind == "fix":
        for it in z.get("old_updates", []):
            if (it.get("violation") or "") == (key or "") and path in it.get("fix_photos", []):
                it["fix_photos"].remove(path)
                _rmfile(path)
    _save_meta(user_fio, check_id, meta)
    return True

# -------------------------------
# Валидация анкеты
# -------------------------------

def _validate(meta: dict, sheet_id: str):
    errors = []
    zones = meta.get("zones") or {}
    if not zones:
        errors.append("Анкета не содержит зон.")
        return errors

    for zn, z in zones.items():
        if z.get("absent"):
            pr = photo_rules(sheet_id, meta.get("hospital", ""), zn, None)
            min_zone = pr.get("min_photos_zone", 0)
            if min_zone and (len(z.get("general_photos") or []) < min_zone):
                errors.append(f"Зона '{zn}' отмечена как отсутствующая, но по правилам требуется минимум {min_zone} фото общего плана.")
            continue

        pr_zone = photo_rules(sheet_id, meta.get("hospital", ""), zn, None)
        min_zone = pr_zone.get("min_photos_zone", 0)
        max_zone = pr_zone.get("max_photos_zone", None)

        new = (z.get("new_violations") or [])
        if not new:
            cnt = len(z.get("general_photos") or [])
            if min_zone and cnt < min_zone:
                errors.append(f"В зоне '{zn}' требуется минимум {min_zone} фото общего плана (сейчас {cnt}).")
            if max_zone is not None and cnt > max_zone:
                errors.append(f"В зоне '{zn}' максимум {max_zone} фото общего плана (сейчас {cnt}).")

        for v in new:
            crit = v.get("title", "")
            pr_v = photo_rules(sheet_id, meta.get("hospital", ""), zn, crit)
            min_v = pr_v.get("min_photos_violation", 0)
            max_v = pr_v.get("max_photos_violation", None)
            cmt_req = pr_v.get("comment_required", False)
            photos = v.get("photos") or []
            if min_v and len(photos) < min_v:
                errors.append(f"Нарушение '{crit}' в зоне '{zn}' требует минимум {min_v} фото (сейчас {len(photos)}).")
            if max_v is not None and len(photos) > max_v:
                errors.append(f"Нарушение '{crit}' в зоне '{zn}' максимум {max_v} фото (сейчас {len(photos)}).")
            if cmt_req and not (v.get("comment") or "").strip():
                errors.append(f"Нарушение '{crit}' в зоне '{zn}' требует обязательный комментарий.")

        for it in (z.get("old_updates") or []):
            if (it.get("violation") and not it.get("status")):
                errors.append(f"Старое нарушение '{it.get('violation')}' в зоне '{zn}' без статуса.")

    return errors

# -------------------------------
# Финализация анкеты
# -------------------------------

def finalize_check(project_sheet_id: str, project_key: str, user_fio: str, check_id: str,
                   add_violation_fn, update_old_fn, force: bool = False):
    meta = _load_meta(user_fio, check_id)
    if not meta:
        return {"ok": False, "error": "NOT_FOUND"}

    if (meta.get("status") or "draft") == "closed":
        return {"ok": True, "already_closed": True, "added": 0, "updated": 0}

    errs = _validate(meta, project_sheet_id)
    if errs and not force:
        return {"ok": False, "errors": errs}

    # Определяем папку Drive по проекту
    project_key = (project_key or "").upper()
    proj_folder_id = (
        os.getenv(f"DRIVE_FOLDER_ID_{project_key}", "")
        or os.getenv("DRIVE_FOLDER_ID_DEFAULT", "")
    )

    total_photos = 0
    added = 0
    updated = 0

    def _upload_list(paths, zone_label, prefix):
        nonlocal total_photos
        links = []
        for p in (paths or []):
            if not os.path.isfile(p):
                continue
            name = f"{check_id}_{_slug(zone_label)}_{prefix}_{os.path.basename(p)}"
            try:
                up = drive_upload(p, name, mime="image/jpeg", folder_id=proj_folder_id)
                url = up.get("view") or up.get("download")
                if url:
                    links.append(url)
                total_photos += 1
            except Exception as e:
                log.exception(f"drive_upload_error path={p} err={e}")
        return links

    zones = meta.get("zones") or {}
    for zone_name, z in zones.items():
        # --- Зона отсутствует ---
        if z.get("absent"):
            add_violation_fn(
                inspector=user_fio, check_id=check_id,
                hospital=meta.get("hospital", ""), object_name=meta.get("object", ""),
                zone=zone_name, violation="Нет", photo_violation_links=[], comment=""
            )
            update_old_fn(
                hospital=meta.get("hospital", ""), object_name=meta.get("object", ""),
                zone=zone_name, violation="Нет", new_status="Зона отсутствует", photo_fix_links=[]
            )
            continue

        # --- Новые нарушения ---
        for v in (z.get("new_violations") or []):
            vio_links = _upload_list(v.get("photos") or [], zone_name, "vio")
            add_violation_fn(
                inspector=user_fio, check_id=check_id,
                hospital=meta.get("hospital", ""), object_name=meta.get("object", ""),
                zone=zone_name, violation=v.get("title", ""), photo_violation_links=vio_links,
                comment=v.get("comment", "")
            )
            added += 1

        # --- Старые нарушения (устранения) ---
        for upd in (z.get("old_updates") or []):
            if not (upd.get("violation") and upd.get("status")):
                continue
            fix_links = _upload_list(upd.get("fix_photos") or [], zone_name, "fix")
            ok = update_old_fn(
                hospital=meta.get("hospital", ""), object_name=meta.get("object", ""),
                zone=zone_name, violation=upd.get("violation"), new_status=upd.get("status"),
                photo_fix_links=fix_links
            )
            if ok:
                updated += 1

        # --- Фото общего плана ---
        _ = _upload_list(z.get("general_photos") or [], zone_name, "gen")

    meta["status"] = "closed"
    meta["closed_at"] = now_str()
    with open(_meta_path(user_fio, check_id), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)

    log_actions.info(
        f'check_finalize user="{user_fio}" id="{check_id}" project="{project_key}" '
        f'zones={len(zones)} added={added} updated={updated} photos={total_photos}'
    )
    return {"ok": True, "added": added, "updated": updated, "photos": total_photos}
