import re

FIELDS = {
  "db": {
    "hospital": [r"^больниц", r"^hospital"],
    "object":   [r"^объект", r"^object"],
    "zone":     [r"^зона", r"^zone"],
    "violation":[r"^наруш", r"^violation", r"^нет$"],
    "photo_violation":[r"^фото\s*наруш", r"^photo.*viol"],
    "comment":  [r"^коммент", r"^comment"],
    "status":   [r"^статус", r"^status"],
    "photo_fix":[r"^фото\s*устран", r"^photo.*fix"],
    "updated_at":[r"^дата", r"^обнов", r"updated"],
    "inspector":[r"^фио", r"^инспектор", r"inspector"],
    "check_id": [r"^id", r"^провер", r"check"],
  }
}

def resolve_header_indices(headers, patterns):
    idx = {}
    low = [h.strip().lower() for h in headers]
    for key, pats in patterns.items():
        found = None
        for patt in pats:
            for i, h in enumerate(low):
                if re.search(patt, h, re.IGNORECASE):
                    found = i
                    break
            if found is not None: break
        idx[key] = found
    return idx

def get_fields_map(kind: str):
    return FIELDS[kind]

def get_all_as_dicts(worksheet, fmap):
    rows = worksheet.get_all_values()
    if not rows: return []
    headers = rows[0]
    idx = resolve_header_indices(headers, fmap)
    out = []
    for r in rows[1:]:
        d={}
        for key, pos in idx.items():
            d[key] = (r[pos] if (pos is not None and pos < len(r)) else "")
        out.append(d)
    return out

def append_row_by_map(worksheet, data: dict, fmap):
    rows = worksheet.get_all_values()
    if not rows:
        headers = list(fmap.keys())
        worksheet.append_row(headers)
        rows = worksheet.get_all_values()
    headers = rows[0]
    idx = resolve_header_indices(headers, fmap)
    row = ["" for _ in headers]
    for k, v in data.items():
        pos = idx.get(k)
        if pos is not None and pos < len(row):
            row[pos] = v
    worksheet.append_row(row)

def write_row_values(worksheet, row_index: int, data: dict, fmap):
    rows = worksheet.get_all_values()
    headers = rows[0]
    idx = resolve_header_indices(headers, fmap)
    for k, v in data.items():
        pos = idx.get(k)
        if pos is None: continue
        worksheet.update_cell(row_index, pos+1, v)

def find_row_index_by_key_value(worksheet, key_patterns, value: str):
    rows = worksheet.get_all_values()
    if not rows: return None
    headers = rows[0]
    idx = None
    low = [h.strip().lower() for h in headers]
    for patt in key_patterns:
        for i, h in enumerate(low):
            import re
            if re.search(patt, h, re.IGNORECASE):
                idx = i; break
        if idx is not None: break
    if idx is None: return None
    for i, r in enumerate(rows[1:], start=2):
        if idx < len(r) and (r[idx] or "").strip() == value.strip():
            return i
    return None
