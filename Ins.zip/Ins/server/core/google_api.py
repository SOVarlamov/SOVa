import os
import json
import logging
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
import gspread

log = logging.getLogger("api")

# OAuth 2.0 scopes
SCOPES = [
    "https://www.googleapis.com/auth/drive.file",
    "https://www.googleapis.com/auth/spreadsheets"
]

# путь до твоего токена
TOKEN_PATH = os.getenv("GOOGLE_TOKEN_JSON", "server/google-token.json")


def _creds() -> Credentials:
    """
    Загружает OAuth-токен из server/google-token.json,
    автоматически обновляет его, если истёк срок действия.
    """
    if not os.path.exists(TOKEN_PATH):
        raise RuntimeError(f"Token file not found: {TOKEN_PATH}")

    # читаем JSON токена
    with open(TOKEN_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)

    creds = Credentials.from_authorized_user_info(data, scopes=SCOPES)

    # если токен просрочен — обновляем и сохраняем обратно
    if creds and creds.expired and creds.refresh_token:
        from google.auth.transport.requests import Request
        try:
            creds.refresh(Request())
            with open(TOKEN_PATH, "w", encoding="utf-8") as f:
                f.write(creds.to_json())
            log.info("Google token refreshed successfully.")
        except Exception as e:
            log.error(f"Failed to refresh Google token: {e}")

    return creds


# ---------------- Google Sheets ----------------

def open_sheet_by_id(sheet_id: str):
    """
    Возвращает объект Google Sheet по ID.
    Работает под твоим аккаунтом (через токен).
    """
    creds = _creds()
    gc = gspread.authorize(creds)
    return gc.open_by_key(sheet_id)


# ---------------- Google Drive ----------------

def drive_service():
    """
    Возвращает клиент Drive API (v3).
    """
    creds = _creds()
    return build("drive", "v3", credentials=creds, cache_discovery=False)


def drive_upload(path: str, name: str, mime: str, folder_id: str):
    """
    Загружает файл на Google Drive в указанную папку.
    Возвращает словарь с ID и ссылками.
    """
    try:
        svc = drive_service()
        media = MediaFileUpload(path, mimetype=mime, resumable=True)
        metadata = {"name": name}
        if folder_id:
            metadata["parents"] = [folder_id]

        file = svc.files().create(
            body=metadata,
            media_body=media,
            fields="id, webViewLink, webContentLink"
        ).execute()

        return {
            "id": file["id"],
            "view": file.get("webViewLink"),
            "download": file.get("webContentLink")
        }

    except Exception as e:
        log.exception(f"drive_upload_error path={path} err={e}")
        return {}
