import threading, queue, logging, time
from server.core.google_api import drive_upload

log = logging.getLogger("media")

class DriveQueue:
    def __init__(self):
        self.q = queue.Queue()
        self.th = None
        self.alive = False

    def start(self):
        if self.th: return
        self.alive = True
        self.th = threading.Thread(target=self._run, daemon=True)
        self.th.start()

    def stop(self):
        self.alive = False

    def put(self, path, name, mime, folder):
        self.q.put((path, name, mime, folder))

    def _run(self):
        while self.alive:
            try:
                path, name, mime, folder = self.q.get(timeout=1)
                res = drive_upload(path, name, mime, folder)
                log.info(f"drive_upload name={name} id={res.get('id')}")
            except queue.Empty:
                pass
            except Exception as e:
                log.exception(f"drive_queue_error err={e}")
            time.sleep(0.1)

drive_queue = DriveQueue()
