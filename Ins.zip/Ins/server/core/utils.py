import os, re, uuid, logging, zipfile
from datetime import datetime, timedelta

logger = logging.getLogger("api")
log_access = logging.getLogger("access")
log_actions = logging.getLogger("actions")
log_media = logging.getLogger("media")
log_err = logging.getLogger("errors")

def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def gen_id(prefix=""):
    return (prefix + datetime.now().strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:8]).strip("-")

def ensure_dir(p: str):
    os.makedirs(p, exist_ok=True)
    return p

def _zip_dir(src_dir: str, zip_path: str):
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for root, _, files in os.walk(src_dir):
            for f in files:
                fp = os.path.join(root, f)
                arc = os.path.relpath(fp, start=os.path.dirname(src_dir))
                z.write(fp, arcname=arc)
    return os.path.getsize(zip_path) if os.path.exists(zip_path) else 0

def cleanup_snapshots(root: str, ttl_hours: int):
    if not os.path.isdir(root): return
    backup_dir = ensure_dir(os.getenv("BACKUP_DIR","server/backup/old_snapshots"))
    keep_days = int(os.getenv("BACKUP_TTL_DAYS","7"))
    limit = datetime.now() - timedelta(hours=ttl_hours)

    for user in os.listdir(root):
        upath = os.path.join(root, user)
        if not os.path.isdir(upath): continue
        for check in os.listdir(upath):
            cpath = os.path.join(upath, check)
            try:
                mtime = datetime.fromtimestamp(os.path.getmtime(cpath))
                if mtime < limit:
                    zip_name = f"{user}__{check}.zip"
                    zip_path = os.path.join(backup_dir, zip_name)
                    size = _zip_dir(cpath, zip_path)
                    for base, dirs, files in os.walk(cpath, topdown=False):
                        for f in files:
                            try: os.remove(os.path.join(base, f))
                            except: pass
                        for d in dirs:
                            try: os.rmdir(os.path.join(base, d))
                            except: pass
                    try: os.rmdir(cpath)
                    except: pass
                    log_actions.info(f'snapshot_archived user="{user}" check="{check}" zip="{zip_path}" size={size}')
            except Exception as e:
                log_err.exception(f"cleanup_error path={cpath} err={e}")

    try:
        if os.path.isdir(backup_dir):
            for f in os.listdir(backup_dir):
                if not f.endswith(".zip"): continue
                p = os.path.join(backup_dir, f)
                mtime = datetime.fromtimestamp(os.path.getmtime(p))
                if mtime < datetime.now() - timedelta(days=keep_days):
                    try:
                        os.remove(p)
                        log_actions.info(f'backup_remove path="{p}"')
                    except: pass
    except Exception as e:
        log_err.exception(f"cleanup_archives_error err={e}")

SPLIT_RE = re.compile(r"[,\s;]+")

def split_links(cell: str):
    if not cell: return []
    parts = [p.strip() for p in SPLIT_RE.split(cell) if p.strip()]
    return [p for p in parts if re.match(r"^https?://", p)]
