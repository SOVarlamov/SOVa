import os, logging
from logging.handlers import RotatingFileHandler

def setup_logging():
    log_dir = os.getenv("LOG_DIR","server/logs")
    os.makedirs(log_dir, exist_ok=True)

    fmt = logging.Formatter('%(asctime)s %(levelname)s %(name)s %(message)s')

    def mk(name, file):
        logger = logging.getLogger(name)
        logger.setLevel(logging.INFO)
        fh = RotatingFileHandler(os.path.join(log_dir, file), maxBytes=5*1024*1024, backupCount=3, encoding="utf-8")
        fh.setFormatter(fmt)
        logger.addHandler(fh)
        sh = logging.StreamHandler()
        sh.setFormatter(fmt)
        logger.addHandler(sh)
        return logger

    mk("actions", "actions.log")
    mk("media", "media.log")
    mk("errors", "errors.log")
    mk("api", "api.log")
    mk("access", "access.log")
