import os, time, hmac, hashlib, base64, json

SECRET = os.getenv("AUTH_SECRET","change_me").encode()
TTL = int(os.getenv("TOKEN_TTL_HOURS","72"))*3600

def sign(payload: dict) -> str:
    data = payload.copy()
    data["exp"] = int(time.time()) + TTL
    raw = json.dumps(data, ensure_ascii=False, separators=(",",":")).encode()
    sig = hmac.new(SECRET, raw, hashlib.sha256).digest()
    return base64.urlsafe_b64encode(raw + b"." + sig).decode()

def verify_token(token: str):
    try:
        blob = base64.urlsafe_b64decode(token.encode())
        raw, sig = blob.rsplit(b".",1)
        calc = hmac.new(SECRET, raw, hashlib.sha256).digest()
        if not hmac.compare_digest(sig, calc): return False, {}
        data = json.loads(raw.decode())
        if int(time.time()) > int(data.get("exp",0)): return False, {}
        return True, data
    except Exception:
        return False, {}
